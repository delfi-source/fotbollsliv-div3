# ⚽ fotbollsliv-div3

Automatisk datahämtning för Division 3 herrar 2026 via Sofascores API.  
Publicerar JSON-filer som statisk API via GitHub Pages → Emergent hämtar dem.

## Så funkar det

```
Sofascore API  →  GitHub Actions (varje timme)  →  GitHub Pages (JSON)  →  Emergent / fotbollsliv.com
```

1. **Scraper** (`scraper.py`) hämtar tabeller och matcher från Sofascore
2. **GitHub Actions** kör scrapern varje hel timme 06:00–23:00 svensk tid
3. **GitHub Pages** servar JSON-filerna som en statisk API
4. **Emergent** hämtar JSON-filerna och visar data på fotbollsliv.com

## Setup — steg för steg

### 1. Skapa GitHub-repo

```bash
# Klona eller skapa nytt repo
git clone https://github.com/DITT-NAMN/fotbollsliv-div3.git
cd fotbollsliv-div3

# Kopiera in filerna (scraper.py, .github/workflows/scrape.yml, docs/)
# Committa och pusha
git add .
git commit -m "Initial setup"
git push
```

### 2. Aktivera GitHub Pages

1. Gå till **Settings** → **Pages** i repot
2. Under "Source", välj **Deploy from a branch**
3. Välj branch: `main`, mapp: `/docs`
4. Klicka **Save**

Din API blir tillgänglig på:  
`https://DITT-NAMN.github.io/fotbollsliv-div3/api/meta.json`

### 3. Ge Actions skrivbehörighet

1. Gå till **Settings** → **Actions** → **General**
2. Under "Workflow permissions", välj **Read and write permissions**
3. Klicka **Save**

### 4. Testkör manuellt

1. Gå till **Actions** → **Scrape Division 3 data**
2. Klicka **Run workflow** → **Run workflow**
3. Vänta ~5 min, kontrollera att JSON-filer dyker upp i `docs/api/`

### 5. Koppla till Emergent

I Emergent, använd fetch för att hämta data:

```
Hämta data från:
https://DITT-NAMN.github.io/fotbollsliv-div3/api/meta.json
https://DITT-NAMN.github.io/fotbollsliv-div3/api/standings.json
https://DITT-NAMN.github.io/fotbollsliv-div3/api/matches.json
https://DITT-NAMN.github.io/fotbollsliv-div3/api/series/20963.json  (per serie)
```

## JSON-struktur

### meta.json
```json
{
  "uppdaterad": "2026-04-18T14:00:00Z",
  "sasong": 2026,
  "serier": [
    {
      "namn": "Division 3 Södra Norrland",
      "id": 20963,
      "spelade": 19,
      "kommande": 113,
      "totalt": 132
    }
  ],
  "totalt_matcher": 1584,
  "totalt_spelade": 228,
  "totalt_kommande": 1356
}
```

### standings.json
```json
{
  "uppdaterad": "2026-04-18T14:00:00Z",
  "tabeller": [
    {
      "pos": 1,
      "lag": "Bollnäs GIF",
      "lag_id": 251243,
      "s": 3, "v": 3, "o": 0, "f": 0,
      "gm": 8, "im": 3, "ms": 5, "p": 9,
      "flytt": "Promotion",
      "serie": "Division 3 Södra Norrland",
      "serie_id": 20963
    }
  ]
}
```

### matches.json
```json
{
  "uppdaterad": "2026-04-18T14:00:00Z",
  "matcher": [
    {
      "id": 12345678,
      "omgang": 3,
      "datum": "2026-04-12",
      "dag": "Lör",
      "tid": "14:00",
      "hemma": "Bollnäs GIF",
      "hemma_id": 251243,
      "borta": "Avesta AIK",
      "borta_id": 35193,
      "hm": 4, "bm": 0,
      "resultat": "4–0",
      "status": "Slutförd",
      "serie": "Division 3 Södra Norrland",
      "serie_id": 20963
    }
  ]
}
```

## Schema

Cron kör i UTC. Schemat `0 4-21 * * *` motsvarar:
- **Sommartid (CEST):** varje hel timme 06:00–23:00
- **Vintertid (CET):** varje hel timme 05:00–22:00

GitHub Actions har ~5 min fördröjning på cron-triggers.

## Filstruktur

```
fotbollsliv-div3/
├── scraper.py                      ← Huvudscript
├── requirements.txt                ← Python-beroenden
├── .github/
│   └── workflows/
│       └── scrape.yml              ← GitHub Actions schema
└── docs/                           ← GitHub Pages root
    ├── index.html                  ← API-dokumentation
    └── api/                        ← Genererade JSON-filer
        ├── meta.json
        ├── standings.json
        ├── matches.json
        └── series/
            ├── 20959.json
            ├── 20960.json
            └── ...
```

## Felsökning

| Problem | Lösning |
|---------|---------|
| Actions kör inte | Kontrollera att Actions är aktiverat i repo-settings |
| 403 från Sofascore | Cloudflare-block — scriptet väntar automatiskt 30–90s |
| Inga JSON-filer | Kolla Actions-loggen, kör manuellt via workflow_dispatch |
| Emergent får CORS-fel | GitHub Pages har öppna CORS-headers som standard |
| Data uppdateras inte | Kontrollera att "Read and write permissions" är aktiverat |
